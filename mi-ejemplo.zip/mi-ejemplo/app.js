const express = require('express');
const bodyParser = require('body-parser');
const path = require('path'); // Necesario para servir archivos estáticos
const app = express();
const port = 3000;

// Almacenar registros y cálculos
const requestLogs = [];
const calculationsHistory = []; // Array para almacenar el historial de cálculos

// Middleware de registro de actividad
const loggerMiddleware = (req, res, next) => {
  const logEntry = `${new Date().toISOString()} - ${req.method} ${req.url}`;
  console.log(logEntry);
  requestLogs.push(logEntry);
  next();
};

// Middleware para analizar el cuerpo de las solicitudes
app.use(bodyParser.urlencoded({ extended: true }));

// Servir archivos estáticos (CSS e imágenes)
app.use(express.static(path.join(__dirname, 'public')));

// Usar el middleware de logger en todas las rutas
app.use(loggerMiddleware);

// Página principal que muestra la calculadora y el historial
app.get('/', (req, res) => {
  let historyHTML = calculationsHistory.map(calc => `<li>${calc}</li>`).join('');
  if (!historyHTML) {
    historyHTML = '<p>Aún no se han hecho cálculos.</p>';
  }
  res.send(`
    <html>
    <head>
      <link rel="stylesheet" href="/styles.css">
      <title>Calculadora</title>
    </head>
    <body>
      <div class="container">
        <h1>¡Bienvenido a la calculadora!</h1>
        <form action="/calculate" method="POST">
          <input type="number" name="num1" placeholder="Número 1" required>
          <input type="number" name="num2" placeholder="Número 2" required>
          <select name="operation" required>
            <option value="add">Sumar</option>
            <option value="subtract">Restar</option>
            <option value="multiply">Multiplicar</option>
          </select>
          <button type="submit">Calcular</button>
        </form>

        <h2>Historial de cálculos:</h2>
        <ul>${historyHTML}</ul>
      </div>
    </body>
    </html>
  `);
});

// Ruta para manejar las operaciones matemáticas
app.post('/calculate', (req, res) => {
  const num1 = parseFloat(req.body.num1);
  const num2 = parseFloat(req.body.num2);
  const operation = req.body.operation;
  let result;

  switch (operation) {
    case 'add':
      result = num1 + num2;
      break;
    case 'subtract':
      result = num1 - num2;
      break;
    case 'multiply':
      result = num1 * num2;
      break;
    default:
      result = 'Operación no válida';
  }

  const calculation = `${num1} ${operation === 'add' ? '+' : operation === 'subtract' ? '-' : '*'} ${num2} = ${result}`;
  calculationsHistory.push(calculation); // Añadir cálculo al historial

  res.redirect('/'); // Redirigir a la página principal para ver el historial
});

// Ruta para obtener los registros de solicitudes (opcional)
app.get('/logs', (req, res) => {
  res.send(`<pre>${requestLogs.join('\n')}</pre>`);
});

// Iniciar el servidor
app.listen(port, () => {
  console.log(`Servidor escuchando en http://localhost:${port}`);
});
